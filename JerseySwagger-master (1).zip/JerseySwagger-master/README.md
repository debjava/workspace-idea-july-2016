# JerseySwagger
Swagger integration with Jersey

working properly
